filename=$1;
path=$(find /home -name $filename);
gedit $path

