#include "lex.h"
#include <stdlib.h>
typedef struct jobs
{
    char name[100];
    pid_t pid;
}jobs;

jobs job[1000];

int sjob(char*l)
{
	int i =0;
 	while(l[i] != NULL)
	{
		if(l[i] == '&')
		{
			l[i] = NULL;
			return 1;
		}
		i++;
	}
	return 0;
}
void deleteJob(int jobpid)
{
	int i ;
	int flag = 0;
	for(i =1 ; i < JOBCTR ; i++)
	{
		if(job[i].pid == jobpid)
			flag = 1;
		if(flag = 1)
			job[i] = job[i+1];
	}
}

void sig_handler(int sig)
{
    if(sig == SIGINT)
    {
        printf("\n");
        invokeShell();
        fflush(stdout);
    }
    if(sig == SIGTSTP)
    {
        printf("\n");
        invokeShell();
        fflush(stdout);
    }
    if(sig == SIGQUIT)
    {
        printf("\n");
        invokeShell();
        fflush(stdout);
    }
    if(sig == SIGCHLD)
    {
 	int  wstat;
        pid_t pid;

        while(1)
        {
            pid = wait3(&wstat,WNOHANG,(struct rusage *)NULL) ;
            if(pid == 0 )
                return;
            else if(pid == -1)
                return;
            else
            {
                fprintf(stderr,"\nProcess with PID : %d exited with return value: %\n",pid,wstat); 
                deleteJob(pid);
            }
        }
    }
}

int backgroundCheck(char **tokens)
{
	int i =0;
 	while(tokens[i] != NULL)
	{
		if(strcmp(tokens[i] , "&")==0)
		{
			tokens[i] = NULL;
			return 1;
		}
		i++;
	}
	return 0;
}
void openfile(char **tokens)
{
	int i = 1;
	int j = 0;
        char input11[100000];	
	int flag1 = 0;
	int flag2 = 0;
	
	while(tokens[i] != NULL)
	{
		int k ;
		for(k=0 ; tokens[i][k] != '\0' ; k++)
		{
			if(flag1 == 1)
			{
				if(tokens[i][k] == '\"')
					flag1= 0;
				else
					input11[j++] = tokens[i][k];
			}else if (flag2==1)
			{
				if(tokens[i][k] == '\'')
				{
				flag2 = 0;	
				}else
				{
				input11[j++] = tokens[i][k];
				}
			}else
			{
				if(tokens[i][k] == '\"')
					flag1=1;
				else if (tokens[i][k] == '\'')
					flag2 = 1;
				else
					input11[j++] = tokens[i][k];
			}
		}
		i++;
	}
	input11[j] = '\0';
char cmd[256]={0};
sprintf(cmd,"%s %s","/usr/bin/ofile.sh",input11);
system(cmd);	
}
void func_PWD()
{
	char home[1000];
	getcwd(home,1000);
	printf(">> %s << \n",home);
}
void func_CD(char **tokens)
{
	char home[1000];
	strcpy(home , execdir);
	int i ;
	int len = strlen(execdir);
	if (tokens[1] == NULL)
		chdir(execdir);
	else if(tokens[1][0] == '~')
	{
		for (i = 1 ; tokens[1][i] != '\0' ; i++)
		{
			home[i+len-1] = tokens[1][i];
		}
		home[i+len-1] = '\0';
		if(chdir(home) != 0)
		{
			perror("Error");
		} 
	}
else if(chdir(tokens[1]) != 0) 
	{
		perror("Error");
	}
}
void func_ECHO(char **tokens)
{
	int i = 1;
	int j = 0;
	char input[100000];

	int flag1 = 0;
	int flag2 = 0;
	
	while(tokens[i] != NULL)
	{
		int k ;
		for(k=0 ; tokens[i][k] != '\0' ; k++)
		{
			if(flag1 == 1)
			{
				if(tokens[i][k] == '\"')
					flag1= 0;
				else
					input[j++] = tokens[i][k];
			}else if (flag2==1)
			{
				if(tokens[i][k] == '\'')
				{
				flag2 = 0;	
				}else
				{
				input[j++] = tokens[i][k];
				}
			}else
			{
				if(tokens[i][k] == '\"')
					flag1=1;
				else if (tokens[i][k] == '\'')
					flag2 = 1;
				else
					input[j++] = tokens[i][k];
			}
		}
		i++;
	}
	input[j] = '\0';
	if(flag1 == 0 && flag2 == 0)
		printf(">> %s << \n ",input);
	else
		printf("Error: Wrong Input\n");
}
void func_show()
{
int pipefd[2];
int pipefd2[2];
int pid;
char buffer[50];
int r;

pipe(pipefd);
pipe(pipefd2);
pid = fork();

if(pid > 0) 
{
write(pipefd[1],"Request",50);
sleep(10);
r=system("/usr/bin/op");
}
else if(pid == 0) 
{
sleep(5);
read(pipefd[0], buffer, sizeof(buffer));
r=system("/usr/bin/show");
}
}
void func_pinfo(char **tokens)
{
	char status[1000] = "cat /proc/";
	int j  = strlen(status);
	if (tokens[1] == NULL)
	{
		char buff[1000] = "";
		ssize_t len = readlink("/proc/self/exe/",buff,sizeof(buff)-1);
		printf(">> Executable Path -- %s << \n",buff);
		char a[20] ="self/status";
		int i;
		for(i = 0 ; a[i] != '\0' ; i++)
			status[j++] = a[i];
	}else
	{
		int i ;
		char b[10] = "/status";
		char a[1000] = "/proc/";
		char c[10] = "/exe";
		int k = 6;
		for(i =0 ; tokens[1][i] != '\0' ; i++)
			a[k++] = tokens[1][i];
		for(i =0 ; c[i] != '0' ; i++)

			a[k++] = c[i];
		char buff[1000] = "";
		ssize_t len = readlink("/proc/self/exe" , a ,sizeof(buff)-1);
		printf("Executable Path -- %s\n",buff);
	  for( i=0 ; tokens[1][i]!='\0' ; i++ )
            status[j++] = tokens[1][i];
        for( i=0 ; b[i]!='\0' ; i++ )
            status[j++] = b[i];
	}
		char *final[1000] = {NULL};
		parse(status,final," ");
	
	pid_t pid;
		int flag;
		  pid = fork();
    if( pid < 0 )
    {
        perror("Forking Error ");
    }
    else if(pid  == 0 )
    {
        if( execvp(*final , final) < 0)
        {
            perror("Error ");
            exit(0);
        }
    }
    else
    {
        wait(&flag);
    }
}
